# EFCC UI design book — Revision 9

5 October 2026 · Owner-confirmed whole Slice 1–2 foundation · selected calm teal direction.

From this directory, run `node serve.mjs` and open the printed URL. Select any of the 40 screens and 306 synthetic states. The catalogue offers 320/390px phone, tablet, desktop and 100%/200% text fixtures. The overview shows primary mobile captures; independent view supports real viewport testing.

Run `node check.mjs` and `node audit-r9/verify.mjs`. The second command validates saved source/evidence hashes and coverage; it does not drive a browser. See [coverage](coverage.md), [foundation](foundation.md) and [QA](design-qa.md).

All data and operations are synthetic, held in memory and reset on reload. This preview does not contact application APIs or D1. Fixture sign-in: Member `wong.tai.ming`, Staff `ui.staff`, password `Demo-only!26`. Shared names deliberately exercise target ambiguity. Lucide exports and their licence are included in `assets/`.

This R9 reference continues feature draft [PR #31](https://github.com/Noahlw/efcc-system/pull/31), local `feat/ui-rework` tracking the retained remote `codex/ui-redesign-grilling`. Production baseline is `100bde89af5b8177e7625bd9b36580c0ab254c43`; production implementation has not started. [Issue #30](https://github.com/Noahlw/efcc-system/issues/30) remains Revision 8 until the owner separately invokes its rewrite. R6 is historical.
