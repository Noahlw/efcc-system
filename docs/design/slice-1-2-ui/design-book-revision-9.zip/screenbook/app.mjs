import { renderScreen, icon } from "./render.mjs";
import {
  getScreen,
  defaultState,
  weekDates,
  previewPhone,
  recoverable,
  rootScreens,
  identityValues,
} from "./screens.mjs";
const query = new URLSearchParams(location.search),
  root = document.querySelector("#app");
// Preview-only text enlargement; physical browser/system scaling still needs device qualification.
if (query.get("textScale") === "200") document.documentElement.style.fontSize = "200%";
let current = getScreen(query.get("screen") || "home").id;
let state = query.get("state") || defaultState(current),
  dirty = false,
  week = 0,
  role = "member";
let applicationStatus =
  current === "application" ? state.replace("ineligible", "") : "pending";
let restriction = null,
  person = null,
  originalOperation = false;
let verifiedPhone = state === "verifiedphone",
  temporaryGate = current === "recovery" && state === "temporary";
let access = !(
  (current === "status" && state !== "active") ||
  (current === "account" &&
    [
      "restricted",
      "deactivated",
      "banned",
      "combined",
      "missing",
      "pendingbanned",
    ].includes(state)) ||
  (["application", "app-edit", "app-withdraw", "app-resubmit"].includes(
    current
  ) &&
    !["approved", "none", "ineligibleapproved"].includes(state))
);
let sensitive = { id: "identity", result: "success" },
  confirmationValid = current === "security" && state === "confirmed",
  pendingNavigation = null;
let confirmationUntil = confirmationValid ? Date.now() + 600_000 : 0;
let phone = null,
  actionTimer = null,
  submitting = false;
let handoverAvailable = true;
let navigationDepth = 0;
let navigationFrom = null,
  confirmationReturn = null;
let checkedStatus =
  current === "status" && state !== "rechecking" ? state : "pending";
const accountStateFor = (value) =>
  value === "pending" ? "restricted" : value === "active" ? "default" : value;
let ownAccountState =
  current === "account"
    ? state
    : current === "status"
      ? accountStateFor(state)
      : access
        ? "default"
        : "restricted";
const retryPage = getScreen(query.get("returnTo") || "home").id;
// Synthetic actors only; this preview never authenticates with the application.
const previewAccounts = new Map([
  [
    "wong.tai.ming",
    {
      fullName: "黃大明",
      email: "demo@example.com",
      phone: "+85260000001",
      password: "Demo-only!26",
      role: "member",
      membership: "active",
    },
  ],
  [
    "wong.tm.02",
    {
      fullName: "黃大明",
      email: "second@example.com",
      phone: "+85260000002",
      password: "Demo-only!26",
      role: "member",
      membership: "active",
    },
  ],
  [
    "ui.staff",
    {
      fullName: "陳同工",
      email: "staff@example.com",
      phone: "+85260000009",
      password: "Demo-only!26",
      role: "staff",
      membership: "active",
    },
  ],
]);
let actorUsername = "wong.tai.ming";
const correctedPeople = new Map();
// ponytail: synthetic in-memory drafts only; real persistence/reconciliation remains a production concern.
const drafts = new Map();
const rootViews = new Map();
let selectedDay = null,
  pendingFocus = null,
  confirmationFocus = null,
  leaveFocus = null;
function captureDraft(form) {
  if (!form) return;
  const values = {};
  for (const input of form.querySelectorAll("input[name],textarea[name],select[name]")) {
    if (/password/i.test(input.name) || (input.type === "radio" && !input.checked)) continue;
    values[input.name] = input.type === "checkbox" ? input.checked : input.value;
  }
  drafts.set(current, values);
}
function filterAccounts(term) {
  let count = 0;
  root.querySelectorAll("[data-searchable]").forEach((row) => {
    row.hidden = !row.dataset.searchable.toLowerCase().includes(term.trim().toLowerCase());
    if (!row.hidden) count++;
  });
  const counter = root.querySelector(".result-count");
  if (counter) counter.textContent = `${count} 個帳戶`;
  const none = root.querySelector("[data-search-empty]");
  if (none) none.hidden = count !== 0;
}
function showWeek() {
    const dates = weekDates(week);
    root.querySelectorAll(".day").forEach((day, i) => {
      day.dataset.day = dates[i];
      day.querySelector("span").textContent = Number(dates[i].slice(8));
      day.classList.toggle("today", week === 0 && i === 0);
      day.classList.remove("selected");
      day.setAttribute("aria-pressed", "false");
      if (["2026-10-11", "2026-10-18"].includes(dates[i]))
        day.dataset.event = "true";
      else delete day.dataset.event;
    });
    const first = new Date(dates[0] + "T00:00:00Z"),
      last = new Date(dates.at(-1) + "T00:00:00Z");
    root.querySelector("[data-month]").textContent =
      first.getUTCFullYear() !== last.getUTCFullYear()
        ? `${first.getUTCFullYear()} 年 ${first.getUTCMonth() + 1} 月 – ${last.getUTCFullYear()} 年 ${last.getUTCMonth() + 1} 月`
        : first.getUTCMonth() === last.getUTCMonth()
          ? `${first.getUTCFullYear()} 年 ${first.getUTCMonth() + 1} 月`
          : `${first.getUTCFullYear()} 年 ${first.getUTCMonth() + 1}–${last.getUTCMonth() + 1} 月`;
    root.querySelector('[data-week="-1"]').disabled = week === 0;
}

function filterDay(raw) {
    const date = raw.includes("-") ? raw : `2026-10-${raw.padStart(2, "0")}`;
    selectedDay = date;
    const day = Number(date.slice(8)),
      month = Number(date.slice(5, 7));
    root
      .querySelectorAll(".day")
      .forEach((button) => {
        const selected = button.dataset.day === date;
        button.classList.toggle("selected", selected);
        button.setAttribute("aria-pressed", String(selected));
      });
    root.querySelector('.date-controls [data-go="home"]').setAttribute("aria-pressed", "false");
    root.querySelector("[data-agenda]").innerHTML = [
      "2026-10-11",
      "2026-10-18",
    ].includes(date)
      ? `<article class="event"><div class="event-date"><strong>${day}</strong>週日</div><div class="event-body"><h3>主日崇拜</h3><p>10:30 · 敬拜部</p><span class="badge">報名已批准</span></div></article>`
      : `<div class="empty">${icon("CalendarDays")}<h2>這一天沒有聚會</h2><p>試試其他日期，或查看全部即將參與的聚會。</p><button class="button secondary" data-go="home">查看全部</button></div>`;
    root
      .querySelector("[data-agenda]")
      .previousElementSibling.querySelector(
        "h2"
      ).textContent = `${month} 月 ${day} 日的聚會`;
}

function render() {
  if (["person", "identity"].includes(current) && !person) {
    const account = previewAccounts.get("wong.tai.ming");
    person = { name: account.fullName, username: "wong.tai.ming", originalUsername: "wong.tai.ming", email: account.email, phone: account.phone, sharedPhone: false };
  }
  root.innerHTML = renderScreen(current, state, {
    ...sensitive,
    role,
    restriction,
    access,
    verifiedPhone,
    temporaryGate,
    applicationStatus,
    phone,
    ownAccountState,
  });
  if (originalOperation && current !== "confirm")
    root
      .querySelector("main")
      ?.insertAdjacentHTML(
        "afterbegin",
        '<div class="notice amber"><strong>重試原操作 · OP-DEMO-001</strong>請填寫相同資料。這次重試會沿用原查核編號。</div>'
      );
  if (
    person &&
    [
      "person",
      "identity",
      "recovery",
      "restrictions",
      "ban",
      "unban",
      "deactivate",
      "reactivate",
      "confirm",
      "handover",
      "operation",
      "deletion",
    ].includes(current)
  ) {
    const walker = document.createTreeWalker(root, NodeFilter.SHOW_TEXT);
    let node;
    while ((node = walker.nextNode())) {
      if (node.parentElement.closest(".desktop-people,.sidebar,.bottom-nav"))
        continue;
      node.textContent = node.textContent
        .replaceAll(current === "deletion" ? "李小恩" : "黃大明", person.name)
        .replaceAll(
          current === "deletion" ? "lee.siu.yan" : "wong.tai.ming",
          person.username
        );
    }
    root
      .querySelectorAll("input[name=fullName]")
      .forEach((n) => (n.value = person.name));
    root
      .querySelectorAll("input[name=username]")
      .forEach((n) => (n.value = person.username));
  }
  if (
    role === "staff" &&
    [
      "home",
      "inbox",
      "account",
      "security",
      "password",
      "sessions",
      "phone",
    ].includes(current)
  ) {
    const walker = document.createTreeWalker(root, NodeFilter.SHOW_TEXT);
    let node;
    while ((node = walker.nextNode()))
      node.textContent = node.textContent
        .replaceAll("黃大明", "陳同工")
        .replaceAll("wong.tai.ming", "ui.staff")
        .replaceAll("大明，早晨。", "同工，早晨。");
  }
  if (
    role !== "staff" &&
    [
      "home",
      "inbox",
      "account",
      "security",
      "phone",
      "password",
      "sessions",
      "status",
      "application",
      "app-edit",
      "app-withdraw",
      "app-resubmit",
    ].includes(current)
  ) {
    const actor = previewAccounts.get(actorUsername);
    const walker = document.createTreeWalker(root, NodeFilter.SHOW_TEXT);
    let node;
    while ((node = walker.nextNode()))
      node.textContent = node.textContent
        .replaceAll("黃大明", actor.fullName)
        .replaceAll("wong.tai.ming", actorUsername)
        .replaceAll("demo@example.com", actor.email);
    if (current === "app-edit")
      for (const name of ["fullName", "email", "phone"])
        root.querySelectorAll(`[name="${name}"]`).forEach(input => { input.value = actor[name]; });
  }
  const valueScreen =
    current === "confirm" ? sensitive.id : current === "apply-result" ? "apply" : current === "handover" && state === "created" ? "create" : current;
  const values = valueScreen === "identity"
    ? identityValues(person || { name: "黃大明", username: "wong.tai.ming", ...previewAccounts.get("wong.tai.ming") }, drafts.get("identity"))
    :
    drafts.get(
      current === "confirm"
        ? sensitive.id
        : current === "apply-result"
          ? "apply"
          : current === "handover" && state === "created"
            ? "create"
            : current
    ) || {};
  if (current === "person" && person) {
    const avatar = root.querySelector(".main .avatar");
    if (avatar) avatar.textContent = person.name.slice(0, 1);
    const contacts = { "電郵": person.email, "電話": person.phone, "共用電話": person.sharedPhone === undefined ? undefined : person.sharedPhone ? "是" : "否" };
    root.querySelectorAll(".summary>div").forEach(row => {
      const value = contacts[row.querySelector("dt")?.textContent];
      if (value !== undefined) row.querySelector("dd").textContent = value || "未提供";
    });
  }
  const fieldMap = {
    申請人: "fullName",
    本人核實: "identityCheck",
    核實方式: "identityCheck",
    中文全名: "fullName",
    Username: "username",
    電郵: "email",
    新電郵: "email",
    電話: "phone",
    新電話: "phone",
    修正電話: "phone",
    共用電話: "sharedPhone",
  };
  root.querySelectorAll(".summary>div").forEach((row) => {
    const key = fieldMap[row.querySelector("dt")?.textContent];
    if (key && Object.hasOwn(values, key))
      row.querySelector("dd").textContent =
        key === "identityCheck"
          ? values[key] === "verified_phone"
            ? "職員主動聯絡教會原有已核實電話"
            : "親身核實"
          : key === "sharedPhone" ? values[key] ? "是" : "否" : values[key] || "未提供";
  });
  if (current === "handover" && state === "created") {
    if (values.fullName)
      root.querySelector(".target strong").textContent = values.fullName;
    if (values.username) {
      root.querySelector(".target small").textContent = values.username;
      root.querySelector(".receipt > strong").textContent = values.username;
    }
  }
  root.querySelectorAll("[data-person]").forEach(row => {
    const original = row.dataset.person.split("|")[1];
    row.dataset.originalUsername = original;
    const correction = correctedPeople.get(original);
    if (!correction) return;
    row.querySelector(".row-copy strong").textContent = correction.name;
    row.querySelector(".row-copy small").textContent = correction.username;
    row.dataset.person = `${correction.name}|${correction.username}`;
    row.dataset.searchable = `${correction.name} ${correction.username}`;
  });
  if (person)
    root
      .querySelectorAll("[data-person]")
      .forEach((row) =>
        row.classList.toggle(
          "selected",
          row.dataset.person.split("|")[1] === person.username
        )
      );
  document.title = `${getScreen(current).title} · 顯恩堂 Design preview`;
  root.dataset.screen = current;
  root.dataset.state = state;
  for (const [name, value] of Object.entries(current === "identity" ? values : drafts.get(current) || {})) {
    if (/password/i.test(name)) continue;
    root.querySelectorAll(`[name="${name}"]`).forEach((el) => {
      if (el.type === "checkbox") el.checked = value === true;
      else if (el.type === "radio") el.checked = el.value === value;
      else el.value = value;
    });
  }
  if (confirmationValid && Date.now() < confirmationUntil) {
    root.querySelectorAll("[data-confirmation-note]").forEach((el) => {
      el.textContent =
        "目前密碼已確認，操作尚未提交。核對資料後，請再次明確提交。";
    });
    root.querySelectorAll("[data-sensitive]").forEach((el) => {
      el.textContent = "確認提交";
    });
  }
  if (current === "confirm" && sensitive.id !== "identity") {
    root.querySelectorAll(".summary dd").forEach((el) => {
      if (el.textContent === "修正身份資料")
        el.textContent = getScreen(sensitive.id).title;
    });
  }
  const dialog = root.querySelector("[role=dialog]");
  if (dialog) {
    const backdrop = dialog.parentElement;
    for (const sibling of backdrop.parentElement.children)
      if (sibling !== backdrop) sibling.inert = true;
    root
      .querySelectorAll(".sidebar,.mobile-head,.bottom-nav")
      .forEach((el) => (el.inert = true));
    (dialog.querySelector("input,button,a") || dialog).focus();
  } else if (pendingFocus) {
    root.querySelector(pendingFocus)?.focus();
    pendingFocus = null;
  }
  const view = rootViews.get(current);
  if (current === "home" && root.querySelector("[data-month]")) {
    week = view?.week ?? 0;
    selectedDay = view?.day ?? root.querySelector(".day.selected")?.dataset.day ?? null;
    showWeek();
    if (selectedDay) filterDay(selectedDay);
  }
  if (view) {
    const search = root.querySelector("[data-search]");
    if (search) { search.value = view.search || ""; filterAccounts(search.value); }
    const main = root.querySelector(".main");
    if (main) main.scrollTop = view.scrollTop;
  }
  window.scrollTo(0, 0);
}
function navigate(
  id,
  nextState = "",
  force = false,
  selectedPerson = null,
  replace = false
) {
  const from = current;
  if (current === "confirm" && id === sensitive.id) {
    dirty = false;
    pendingFocus = confirmationFocus || `[data-sensitive="${sensitive.id}"],[data-go="confirm"]`;
    if (navigationDepth > 0 && navigationFrom === id && !replace) {
      confirmationReturn = { screen: id, state: nextState || defaultState(id) };
      history.back();
      return;
    }
  }
  if (dirty && !force) {
    pendingNavigation = [id, nextState, selectedPerson, replace];
    showLeave();
    return;
  }
  if (rootScreens.has(current)) rootViews.set(current, {
    search: root.querySelector("[data-search]")?.value || "",
    scrollTop: root.querySelector(".main")?.scrollTop || 0,
    week,
    day: selectedDay,
  });
  clearTimeout(actionTimer);
  if (current === "handover" && id !== "handover") handoverAvailable = false;
  if (id === "handover" && !handoverAvailable) nextState = "receipt";
  if (selectedPerson) {
    if (person?.username !== selectedPerson.username)
      for (const id of [
        "identity",
        "recovery",
        "ban",
        "unban",
        "deactivate",
        "reactivate",
        "deletion",
      ])
        drafts.delete(id);
    person = selectedPerson;
  }
  if (
    id === "status" &&
    nextState === "rechecking" &&
    current === "status" &&
    state !== "rechecking"
  )
    checkedStatus = state;
  if (id === "account" && (!nextState || nextState === "restricted"))
    nextState = ownAccountState;
  current = getScreen(id).id;
  state = nextState || defaultState(current);
  if (
    current === "application" &&
    ["pending", "rejected", "withdrawn", "approved"].includes(state)
  )
    applicationStatus = state;
  dirty = false;
  if (current === "status") access = state === "active";
  if (current === "status" && state !== "rechecking")
    ownAccountState = accountStateFor(state);
  if (current === "account") ownAccountState = state;
  if (current === "signin") {
    rootViews.clear();
    role = "member";
    access = true;
    confirmationValid = false;
    confirmationUntil = 0;
  }
  if (getScreen(current).group.startsWith("03") || state === "staff")
    role = "staff";
  if (current === "restrictions")
    restriction = {
      banned: ["banned", "combined"].includes(state),
      deactivated: ["deactivated", "combined"].includes(state),
    };
  if (!replace) navigationDepth++;
  navigationFrom = replace ? history.state?.from ?? null : from;
  history[replace ? "replaceState" : "pushState"](
    { screen: current, state, person, depth: navigationDepth, from: navigationFrom },
    "",
    `?screen=${current}&state=${state}`
  );
  render();
  // Synthetic request timing keeps fixture states inspectable and live journeys complete.
  if (current === "signout" && state === "default")
    actionTimer = setTimeout(() => navigate("signin", "", true), 350);
  if (current === "status" && state === "rechecking")
    actionTimer = setTimeout(
      () => navigate("status", checkedStatus, true),
      350
    );
  if (current === "operation" && state === "checking")
    actionTimer = setTimeout(() => navigate("operation", "retry", true), 350);
  if (current === "confirm" && state === "checking")
    actionTimer = setTimeout(() => navigate("confirm", "expired", true), 350);
  if (recoverable.has(current) && state === "checking") {
    const original = current;
    actionTimer = setTimeout(() => navigate(original, "retrying", true), 350);
  }
  if (current === "apply-result" && state === "checking")
    actionTimer = setTimeout(
      () => navigate("apply-result", "retry", true),
      350
    );
  if (parent !== window)
    parent.postMessage(
      { type: "screenbook", screen: current, state },
      location.origin
    );
}
function showLeave() {
  leaveFocus = document.activeElement;
  root.insertAdjacentHTML(
    "beforeend",
    `<div class="modal-backdrop" data-live-dialog><section class="modal" role="dialog" aria-modal="true" aria-labelledby="unsent-title"><h2 id="unsent-title">放棄未提交的更改？</h2><p>這些更改尚未送出。離開後，需要重新填寫。</p><div class="actions"><button class="button" data-keep>繼續編輯</button><button class="button secondary" data-discard>放棄更改並離開</button></div></section></div>`
  );
  root.querySelector("[data-keep]").focus();
  for (const sibling of root.children)
    if (!sibling.hasAttribute("data-live-dialog")) sibling.inert = true;
}
function closeLeave() {
  root.querySelector("[data-live-dialog]")?.remove();
  root.querySelectorAll("[inert]").forEach((el) => {
    el.inert = false;
  });
  (leaveFocus?.isConnected ? leaveFocus : root.querySelector("input,textarea,select"))?.focus();
  leaveFocus = null;
}
function finishSensitive() {
  const { id, result } = sensitive;
  if (id === "create" || id === "recovery") handoverAvailable = true;
  if (id === "create") {
    const values = drafts.get("create") || {};
    person = { name: values.fullName || "李小恩", username: values.username || "lee.siu.yan", email: values.email, phone: previewPhone(values.phone), sharedPhone: values.sharedPhone || false };
  }
  if (id === "identity") {
    const before = person || {name:"黃大明",username:"wong.tai.ming"};
    const values = identityValues(before, drafts.get("identity"));
    person = {...before,name:values.fullName || before.name,username:values.username || before.username,email:values.email,phone:previewPhone(values.phone),sharedPhone:values.sharedPhone || false};
    correctedPeople.set(before.originalUsername || before.username,person);
    drafts.delete("identity");
  }
  if (id === "create") navigate("handover", "created", true);
  else if (id === "recovery") navigate("handover", result, true);
  else navigate(id, result, true);
}
function fieldError(input, message) {
  const label = input.closest(".field");
  if (!label) return;
  let error = label.querySelector(".error");
  if (!error) {
    error = document.createElement("span");
    error.className = "error";
    error.id = `error-${input.name}`;
    error.setAttribute("role", "alert");
    label.append(error);
  }
  error.textContent = message;
  input.setAttribute("aria-invalid", "true");
  const refs = new Set((input.getAttribute("aria-describedby") || "").split(" ").filter(Boolean));
  refs.add(error.id);
  input.setAttribute("aria-describedby", [...refs].join(" "));
}
root.addEventListener("invalid", (event) => {
  const input = event.target;
  fieldError(input, input.validity.customError ? input.validationMessage : input.validity.valueMissing ? "請填寫此欄位。" : "請檢查輸入格式及長度。");
}, true);
root.addEventListener("input", (event) => {
  const input = event.target;
  if (input.matches("[data-search]")) {
    filterAccounts(input.value);
    return;
  }
  if (input.matches("input,textarea,select")) {
    if (current === "handover") return;
    input.setCustomValidity?.("");
    input.removeAttribute("aria-invalid");
    const error = input.closest(".field")?.querySelector(".error");
    if (error) {
      const refs = (input.getAttribute("aria-describedby") || "").split(" ").filter(id => id && id !== error.id);
      if (refs.length) input.setAttribute("aria-describedby", refs.join(" "));
      else input.removeAttribute("aria-describedby");
      error.remove();
    }
    dirty = true;
    captureDraft(input.form);
  }
});
root.addEventListener("change", (event) => {
  if (
    event.target.name === "identityCheck" ||
    event.target.name === "recoveryAction"
  ) {
    captureDraft(event.target.form);
  }
});
root.addEventListener("submit", (event) => {
  event.preventDefault();
  if (submitting) return;
  const form = event.target;
  captureDraft(form);
  const data = new FormData(form);
  const actor = previewAccounts.get(
    role === "staff" ? "ui.staff" : actorUsername
  );
  if (current === "signin") {
    const matches = [...previewAccounts].filter(([username, account]) =>
      data.has("fullName")
        ? account.fullName === data.get("fullName").trim()
        : username === data.get("username").trim().toLowerCase()
    );
    if (
      matches.length !== 1 ||
      matches[0][1].password !== data.get("currentPassword")
    ) {
      dirty = false;
      navigate(
        "signin",
        matches.length > 1
          ? "ambiguous"
          : data.has("fullName")
            ? "nameinvalid"
            : "invalid",
        true
      );
      return;
    }
    actorUsername = matches[0][0];
    role = matches[0][1].role;
    access = matches[0][1].membership === "active";
    ownAccountState = access
      ? role === "staff"
        ? "staff"
        : "default"
      : "restricted";
    form.dataset.submit = access ? "home" : "status";
    form.dataset.state = access
      ? role === "staff"
        ? "staff"
        : "default"
      : "pending";
    phone = matches[0][1].phone;
  } else if (
    data.has("currentPassword") &&
    data.get("currentPassword") !== actor.password &&
    !(
      current === "temp-password" &&
      data.get("currentPassword") === "Demo-only!26"
    )
  ) {
    const field = form.querySelector('[name="currentPassword"]');
    field.setCustomValidity("目前密碼未能確認，請再輸入。");
    field.reportValidity();
    return;
  }
  const tel = form.querySelector('input[type="tel"]');
  if (tel && !previewPhone(tel.value)) {
    tel.setCustomValidity("請輸入有效的香港或國際電話號碼。");
    tel.reportValidity();
    return;
  }
  if (
    data.has("newPassword") &&
    data.get("newPassword") !== data.get("confirmPassword")
  ) {
    form
      .querySelector("[name=confirmPassword]")
      .setCustomValidity("兩次輸入的新密碼不相符。");
    form.reportValidity();
    return;
  }
  if (current === "confirm") {
    confirmationValid = true;
    confirmationUntil = Date.now() + 600_000;
    dirty = false;
    navigate(
      sensitive.id,
      sensitive.id === "security"
        ? "confirmed"
        : sensitive.reviewState || "review",
      true
    );
    return;
  }
  let nextState = form.dataset.state;
  if (current === "recovery")
    nextState = data.get("recoveryAction") || nextState;
  if (current === "phone") { phone = previewPhone(tel.value); actor.phone = phone; }
  if (current === "app-edit") for (const name of ["fullName","email","phone"]) actor[name] = name === "phone" ? previewPhone(data.get(name)) : data.get(name);
  if (current === "password" || current === "temp-password") {
    actor.password = data.get("newPassword");
    confirmationValid = false;
    confirmationUntil = 0;
  }
  if (current === "apply") {
    if (previewAccounts.has(data.get("username").toLowerCase())) {
      dirty = false;
      navigate("apply-result", "conflict", true);
      return;
    }
    previewAccounts.set(data.get("username").toLowerCase(), {
      fullName: data.get("fullName"),
      email: data.get("email"),
      phone: previewPhone(tel.value),
      password: data.get("password"),
      role: "member",
      membership: "pending",
    });
  }
  const destination = form.dataset.submit;
  dirty = false;
  submitting = true;
  form.setAttribute("aria-busy", "true");
  const submit = form.querySelector('[type="submit"]');
  form.querySelectorAll("input,textarea,select,button").forEach((el) => {
    el.disabled = true;
  });
  submit.textContent = "正在處理…";
  setTimeout(() => {
    submitting = false;
    navigate(destination, nextState, true);
  }, 300);
});
root.addEventListener("click", (event) => {
  const control = event.target.closest("a,button");
  if (!control) return;
  if (submitting) {
    event.preventDefault();
    return;
  }
  if (control.hasAttribute("data-eye")) {
    const input = control.parentElement.querySelector("input");
    input.type = input.type === "password" ? "text" : "password";
    control.setAttribute(
      "aria-label",
      control
        .getAttribute("aria-label")
        .replace(/^(顯示|隱藏)/u, input.type === "password" ? "顯示" : "隱藏")
    );
    return;
  }
  if (control.hasAttribute("data-keep")) {
    closeLeave();
    return;
  }
  if (control.hasAttribute("data-discard")) {
    drafts.delete(current);
    dirty = false;
    const next = pendingNavigation;
    pendingNavigation = null;
    navigate(next[0], next[1], true, next[2], next[3]);
    return;
  }
  if (control.hasAttribute("data-sensitive")) {
    event.preventDefault();
    const required = root.querySelector("input[name=deleteAcknowledged]");
    if (required && !required.checked) {
      required.reportValidity();
      return;
    }
    sensitive = {
      id: control.dataset.sensitive,
      result: control.dataset.result,
      reviewState: state,
    };
    confirmationFocus = `[data-sensitive="${sensitive.id}"]`;
    dirty = false;
    if (!confirmationValid || Date.now() >= confirmationUntil)
      navigate("confirm", "default", true);
    else finishSensitive();
    return;
  }
  if (control.hasAttribute("data-final-submit")) {
    if (!confirmationValid || Date.now() >= confirmationUntil) navigate("confirm","expired",true);
    else finishSensitive();
    return;
  }
  if (control.classList.contains("back") && navigationDepth > 0 && navigationFrom === control.dataset.go) {
    event.preventDefault();
    history.back();
    return;
  }
  if (control.hasAttribute("data-scroll")) {
    event.preventDefault();
    document
      .querySelector("#" + control.dataset.scroll)
      .scrollIntoView({ behavior: "smooth" });
    return;
  }
  if (control.hasAttribute("data-week")) {
    week = Math.max(0, week + Number(control.dataset.week));
    showWeek();
    return;
  }
  if (control.hasAttribute("data-day")) {
    filterDay(control.dataset.day);
    return;
  }
  if (control.dataset.go) {
    event.preventDefault();
    if (current === "home" && control.dataset.go === "home") {
      selectedDay = null; week = 0; rootViews.delete("home");
      root.querySelector(".day.selected")?.classList.remove("selected");
      root.querySelector(".main").scrollTop = 0;
    }
    if (control.hasAttribute("data-reset-application")) {
      drafts.delete("apply");
      drafts.delete("apply-result");
      originalOperation = false;
      dirty = false;
    }
    const selectedPerson = control.dataset.person
      ? (() => {
          const [name, username] = control.dataset.person.split("|");
          const originalUsername = control.dataset.originalUsername || username;
          const fixture = previewAccounts.get(originalUsername);
          return { email: fixture?.email ?? "", phone: fixture?.phone ?? "+85260000003", sharedPhone: false, ...correctedPeople.get(originalUsername), name, username, originalUsername };
        })()
      : null;
    if (control.hasAttribute("data-retry")) originalOperation = true;
    if (control.dataset.go === "confirm" && current === "security")
      { sensitive = { id: "security", result: "confirmed" }; confirmationFocus = '[data-go="confirm"]'; }
    if (current === "handover" && control.dataset.go === "person") {
      const acknowledged = root.querySelector("[name=handover]");
      if (acknowledged && !acknowledged.checked) {
        acknowledged.reportValidity();
        return;
      }
    }
    navigate(
      control.hasAttribute("data-retry-page") ? retryPage : control.dataset.go,
      control.dataset.state || "",
      false,
      selectedPerson
    );
  }
});
document.addEventListener("keydown", (event) => {
  const dialog = root.querySelector("[role=dialog]");
  if (!dialog) return;
  const focusable = [
    ...dialog.querySelectorAll(
      "input:not(:disabled),button:not(:disabled),a[href],textarea,select"
    ),
  ];
  if (event.key === "Tab" && focusable.length) {
    const first = focusable[0],
      last = focusable.at(-1);
    if (event.shiftKey && document.activeElement === first) {
      event.preventDefault();
      last.focus();
    } else if (!event.shiftKey && document.activeElement === last) {
      event.preventDefault();
      first.focus();
    }
  }
  if (event.key === "Escape") {
    if (root.querySelector("[data-live-dialog]")) closeLeave();
    else if (current === "confirm") navigate(sensitive.id, sensitive.reviewState || (sensitive.id === "security" ? "default" : "review"), true);
    else if (current === "leave") navigate("identity", "default", true);
  }
});
window.addEventListener("beforeunload", (event) => {
  if (dirty) {
    event.preventDefault();
    event.returnValue = "";
  }
});
window.addEventListener("popstate", (event) => {
  if (!event.state?.screen) return;
  const destination = event.state;
  if (dirty) {
    history.pushState(
      { screen: current, state, person, depth: navigationDepth, from: navigationFrom },
      "",
      `?screen=${current}&state=${state}`
    );
    pendingNavigation = [
      destination.screen,
      destination.state,
      destination.person,
      false,
    ];
    showLeave();
    return;
  }
  navigationDepth = destination.depth || 0;
  const returnState = confirmationReturn?.screen === destination.screen ? confirmationReturn.state : destination.state;
  confirmationReturn = null;
  navigate(
    destination.screen,
    returnState,
    true,
    destination.person,
    true
  );
});
if (getScreen(current).group.startsWith("03") || ["confirm", "leave", "operation"].includes(current) || state === "staff")
  role = "staff";
if (current === "restrictions")
  restriction = {
    banned: ["banned", "combined"].includes(state),
    deactivated: ["deactivated", "combined"].includes(state),
  };
if (current === "handover" && state === "created")
  person = { name: "李小恩", username: "lee.siu.yan", email: "", phone: "+85260000003", sharedPhone: false };
history.replaceState(
  { screen: current, state, person, depth: 0, from: null },
  "",
  location.href
);
render();
