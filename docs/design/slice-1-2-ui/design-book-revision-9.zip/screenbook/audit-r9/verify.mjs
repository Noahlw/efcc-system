import assert from "node:assert/strict";
import { createHash } from "node:crypto";
import { readFileSync } from "node:fs";
import { dirname, resolve } from "node:path";
import { fileURLToPath } from "node:url";

const here = dirname(fileURLToPath(import.meta.url));
const read = (file) => JSON.parse(readFileSync(resolve(here, file), "utf8"));
const manifest = read("manifest.json");
for (const [base, entries] of [[resolve(here, ".."), manifest.source], [here, manifest.evidence]]) {
  for (const [file, expected] of Object.entries(entries)) {
    assert.equal(createHash("sha256").update(readFileSync(resolve(base, file))).digest("hex"), expected, `Stale evidence: ${file}`);
  }
}
const geometry = read("geometry.json");
const coverage = JSON.parse(readFileSync(resolve(here, "../coverage.json"), "utf8"));
const ids = coverage.screens.map((s) => s.id).sort();
assert.equal(geometry.filter((r) => !r.textScale).length, 240);
assert.equal(geometry.filter((r) => r.textScale).length, 80);
for (const [width, height, textScale] of [[320, 568, false], [390, 844, false], [768, 1024, false], [1024, 768, false], [1440, 1024, false], [844, 390, false], [320, 568, true], [1440, 1024, true]]) {
  assert.deepEqual(geometry.filter((r) => r.width === width && r.height === height && r.textScale === textScale).map((r) => r.screen).sort(), ids);
}
for (const row of [...geometry, ...read("variants.json")]) {
  assert.equal(row.mainTitles, 1, `${row.screen}: title count`);
  assert.ok(["root", "task", "auth"].includes(row.layout), `${row.screen}: layout role`);
  assert.ok(!row.overflow && !row.clippedMain, `${row.screen}: clipped content`);
  assert.ok(!row.smallTargets?.length, `${row.screen}: small target`);
  if (row.nav) assert.ok(Math.abs(row.nav.bottomGap) <= 1 && row.nav.overlap <= 1, `${row.screen}: navigation obstruction`);
  if (row.dialog) assert.ok(row.dialog.left >= -1 && row.dialog.right <= row.width + 1 && row.dialog.top >= -1 && row.dialog.bottom <= row.height + 1, `${row.screen}: dialog bounds`);
  if (row.textScale) assert.equal(row.bodyFont, "34px");
}
assert.equal(read("variants.json").length, 306);
assert.deepEqual(read("variants.json").map((r) => `${r.screen}/${r.state}`).sort(), coverage.screens.flatMap((s) => s.variants.map(([state]) => `${s.id}/${state}`)).sort());
assert.ok(read("variants.json").every((r) => r.width === 320 && r.height === 568));
assert.equal(read("interaction-checks.json").length, 21);
assert.ok(read("interaction-checks.json").every((r) => r.passed === true));
const ends = read("end-controls.json");
assert.deepEqual(ends.map((r) => r.screen).sort(), ids);
assert.ok(ends.every((r) => r.passed), "Unreachable final control");
assert.deepEqual(read("runtime-logs.json"), []);
console.log("R9 reference evidence: source hashes, 240 viewport cases, 80 text cases, 306 states and all recorded interaction checks passed.");
