import { screens, getScreen, defaultState, escape as e } from "./screens.mjs";
const catalog = document.querySelector("#catalog");
for (const group of [...new Set(screens.map((s) => s.group))])
  catalog.insertAdjacentHTML(
    "beforeend",
    `<section><h2 class="group-title">${e(group)}</h2>${screens
      .filter((s) => s.group === group)
      .map(
        (s) =>
          `<a href="#${s.id}" data-screen="${s.id}"><small>${String(screens.indexOf(s) + 1).padStart(2, "0")}</small>${e(s.title)}</a>`
      )
      .join("")}</section>`
  );
const stateSelect = document.querySelector("#state"),
  frame = document.querySelector("#preview"),
  textScale = document.querySelector("#text-scale");
let screen = "home",
  state = "default",
  fromPreview = false;
function render() {
  const [id, variant] = location.hash.slice(1).split("/");
  screen = getScreen(id || "home").id;
  const item = getScreen(screen);
  state = item.variants.some((v) => v[0] === variant)
    ? variant
    : defaultState(screen);
  stateSelect.innerHTML = item.variants
    .map(
      ([v, title]) =>
        `<option value="${v}" ${v === state ? "selected" : ""}>${e(title)}</option>`
    )
    .join("");
  document.querySelector("#screen-title").textContent = item.title;
  document.querySelector("#source-route").textContent = item.route;
  document.querySelector("#design-note").textContent = item.note;
  catalog
    .querySelectorAll("a")
    .forEach((a) =>
      a.setAttribute(
        "aria-current",
        a.dataset.screen === screen ? "page" : "false"
      )
    );
  const nextSrc = `app.html?screen=${screen}&state=${state}${textScale.value === "200" ? "&textScale=200" : ""}`;
  if (!fromPreview) frame.src = nextSrc;
  fromPreview = false;
  document.querySelector("#open-view").href = nextSrc;
  document.title = `${item.title} · EFCC Design Book`;
}
window.addEventListener("hashchange", render);
stateSelect.addEventListener(
  "change",
  () => (location.hash = `${screen}/${stateSelect.value}`)
);
document.querySelectorAll("[data-size]").forEach((button) =>
  button.addEventListener("click", () => {
    document.body.classList.toggle("wide", button.dataset.size === "wide");
    frame.style.width = `${button.dataset.size === "wide" ? 1280 : button.dataset.size}px`;
    frame.style.height = `${button.dataset.size === "wide" ? 900 : button.dataset.size === "768" ? 1024 : 844}px`;
    document
      .querySelectorAll("[data-size]")
      .forEach((b) => b.setAttribute("aria-pressed", String(b === button)));
  })
);
for (const [id, step] of [
  ["previous", -1],
  ["next", 1],
])
  document
    .querySelector("#" + id)
    .addEventListener(
      "click",
      () =>
        (location.hash =
          screens[
            (screens.findIndex((s) => s.id === screen) +
              step +
              screens.length) %
              screens.length
          ].id)
    );
window.addEventListener("message", (event) => {
  if (
    event.origin !== location.origin ||
    event.source !== frame.contentWindow ||
    event.data?.type !== "screenbook"
  )
    return;
  const next = getScreen(event.data.screen);
  fromPreview = true;
  const nextHash = `${next.id}/${next.variants.some((v) => v[0] === event.data.state) ? event.data.state : defaultState(next.id)}`;
  if (location.hash === `#${nextHash}`) render();
  else location.hash = nextHash;
});
render();

textScale.addEventListener("change", () => { fromPreview = false; render(); });
