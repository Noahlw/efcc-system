# EFCC Slice 1–2 UI reference — R9

All data and operations are synthetic. Production implementation has not started.

Enter `screenbook`, run `node serve.mjs` and open its printed URL. From the same directory run `node check.mjs` and `node audit-r9/verify.mjs`; the latter verifies saved evidence rather than running a browser.

- [Design Book](screenbook/index.html), [overview](screenbook/gallery.html), [native comparison](screenbook/compare.html).
- [Confirmed understanding](understanding.md), [architecture and Route Groups/roles assessment](architecture-research.md), [current UI census](ui-architecture-census.json).
- [Shared foundation and all 40 owners](screenbook/foundation.md), [all 306 states](screenbook/coverage.md), [qualification](screenbook/audit-r9/report.md), [source/evidence hashes](screenbook/audit-r9/manifest.json).
- [Originally selected direction](selected-home-v1.png), [semantic reference refinement](selected-home-v2.png).

[Issue #30](https://github.com/Noahlw/efcc-system/issues/30) remains published Revision 8 pending a separately invoked rewrite. This R9 understanding/reference continues feature draft [PR #31](https://github.com/Noahlw/efcc-system/pull/31). The reference does not certify Worker/D1 or physical-device behavior.
