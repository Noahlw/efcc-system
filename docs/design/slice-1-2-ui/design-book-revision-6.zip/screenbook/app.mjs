import { renderScreen, icon } from "./render.mjs";
import { getScreen, defaultState, weekDates } from "./screens.mjs";
const query = new URLSearchParams(location.search),
  root = document.querySelector("#app");
let current = getScreen(query.get("screen") || "home").id;
let state = query.get("state") || defaultState(current),
  dirty = false,
  week = 0,
  role = "member";
let applicationStatus =
  current === "application" ? state.replace("ineligible", "") : "pending";
let restriction = null,
  person = null,
  originalOperation = false;
let verifiedPhone = state === "verifiedphone",
  temporaryGate = current === "recovery" && state === "temporary";
let access = !(
  (current === "status" && state !== "active") ||
  (current === "account" &&
    ["restricted", "deactivated", "banned", "combined", "missing"].includes(
      state
    )) ||
  (["application", "app-edit", "app-withdraw", "app-resubmit"].includes(
    current
  ) &&
    !["approved", "none", "ineligibleapproved"].includes(state))
);
let sensitive = { id: "identity", result: "success" },
  confirmationValid = false,
  pendingNavigation = null;
// ponytail: synthetic in-memory drafts only; real persistence/reconciliation remains a production concern.
const drafts = new Map();
function render() {
  if (current === "person" && !person)
    person = { name: "黃大明", username: "wong.tai.ming" };
  root.innerHTML = renderScreen(current, state, {
    ...sensitive,
    role,
    restriction,
    access,
    verifiedPhone,
    temporaryGate,
    applicationStatus,
  });
  if (originalOperation && current !== "confirm")
    root
      .querySelector("main")
      ?.insertAdjacentHTML(
        "afterbegin",
        '<div class="notice amber"><strong>重試原操作 · OP-DEMO-001</strong>請填寫相同資料。這次重試會沿用原查核編號。</div>'
      );
  if (
    person &&
    [
      "person",
      "identity",
      "recovery",
      "restrictions",
      "ban",
      "unban",
      "deactivate",
      "reactivate",
      "confirm",
      "handover",
      "operation",
      "deletion",
    ].includes(current)
  ) {
    const walker = document.createTreeWalker(root, NodeFilter.SHOW_TEXT);
    let node;
    while ((node = walker.nextNode())) {
      if (node.parentElement.closest(".desktop-people,.sidebar,.bottom-nav"))
        continue;
      node.textContent = node.textContent
        .replaceAll(current === "deletion" ? "李小恩" : "黃大明", person.name)
        .replaceAll(
          current === "deletion" ? "lee.siu.yan" : "wong.tai.ming",
          person.username
        );
    }
    root
      .querySelectorAll("input[name=fullName]")
      .forEach((n) => (n.value = person.name));
    root
      .querySelectorAll("input[name=username]")
      .forEach((n) => (n.value = person.username));
  }
  if (
    role === "staff" &&
    [
      "home",
      "inbox",
      "account",
      "security",
      "password",
      "sessions",
      "phone",
    ].includes(current)
  ) {
    const walker = document.createTreeWalker(root, NodeFilter.SHOW_TEXT);
    let node;
    while ((node = walker.nextNode()))
      node.textContent = node.textContent
        .replaceAll("黃大明", "陳同工")
        .replaceAll("wong.tai.ming", "ui.staff")
        .replaceAll("大明，早晨。", "同工，早晨。");
  }
  const values =
    drafts.get(
      current === "confirm"
        ? sensitive.id
        : current === "apply-result"
          ? "apply"
          : current === "handover" && state === "created"
            ? "create"
            : current
    ) || {};
  const fieldMap = {
    申請人: "fullName",
    本人核實: "identityCheck",
    核實方式: "identityCheck",
    中文全名: "fullName",
    Username: "username",
    電郵: "email",
    新電郵: "email",
    電話: "phone",
    新電話: "phone",
    修正電話: "phone",
  };
  root.querySelectorAll(".summary>div").forEach((row) => {
    const key = fieldMap[row.querySelector("dt")?.textContent];
    if (key && values[key])
      row.querySelector("dd").textContent =
        key === "identityCheck"
          ? values[key] === "verified_phone"
            ? "職員主動聯絡教會原有已核實電話"
            : "親身核實"
          : values[key];
  });
  if (current === "handover" && state === "created") {
    if (values.fullName)
      root.querySelector(".target strong").textContent = values.fullName;
    if (values.username) {
      root.querySelector(".target small").textContent = values.username;
      root.querySelector(".receipt > strong").textContent = values.username;
    }
  }
  if (person)
    root
      .querySelectorAll("[data-person]")
      .forEach((row) =>
        row.classList.toggle(
          "selected",
          row.dataset.person.split("|")[1] === person.username
        )
      );
  document.title = `${getScreen(current).title} · 顯恩堂 Design preview`;
  root.dataset.screen = current;
  root.dataset.state = state;
  for (const [name, value] of Object.entries(drafts.get(current) || {})) {
    if (/password/i.test(name)) continue;
    root.querySelectorAll(`[name="${name}"]`).forEach((el) => {
      if (el.type === "checkbox") el.checked = value === true;
      else if (el.type === "radio") el.checked = el.value === value;
      else el.value = value;
    });
  }
  if (confirmationValid)
    root.querySelectorAll("[data-confirmation-note]").forEach((el) => {
      el.textContent =
        "目前密碼已確認，操作尚未提交。核對資料後，請再次明確提交。";
    });
  if (current === "confirm" && sensitive.id !== "identity") {
    root.querySelectorAll(".summary dd").forEach((el) => {
      if (el.textContent === "修正身份資料")
        el.textContent = getScreen(sensitive.id).title;
    });
  }
  const dialog = root.querySelector("[role=dialog]");
  if (dialog) {
    const backdrop = dialog.parentElement;
    for (const sibling of backdrop.parentElement.children)
      if (sibling !== backdrop) sibling.inert = true;
    root
      .querySelectorAll(".sidebar,.mobile-head,.bottom-nav")
      .forEach((el) => (el.inert = true));
    (dialog.querySelector("input,button,a") || dialog).focus();
  }
  window.scrollTo(0, 0);
}
function navigate(id, nextState = "", force = false) {
  if (dirty && !force) {
    pendingNavigation = [id, nextState];
    showLeave();
    return;
  }
  current = getScreen(id).id;
  state = nextState || defaultState(current);
  if (
    current === "application" &&
    ["pending", "rejected", "withdrawn", "approved"].includes(state)
  )
    applicationStatus = state;
  dirty = false;
  week = 0;
  if (current === "status") access = state === "active";
  if (current === "signin") {
    role = "member";
    access = true;
    confirmationValid = false;
  }
  if (getScreen(current).group.startsWith("03") || state === "staff")
    role = "staff";
  if (current === "restrictions")
    restriction = {
      banned: ["banned", "combined"].includes(state),
      deactivated: ["deactivated", "combined"].includes(state),
    };
  history.replaceState(null, "", `?screen=${current}&state=${state}`);
  render();
  if (parent !== window)
    parent.postMessage(
      { type: "screenbook", screen: current, state },
      location.origin
    );
}
function showLeave() {
  root.insertAdjacentHTML(
    "beforeend",
    `<div class="modal-backdrop" data-live-dialog><section class="modal" role="dialog" aria-modal="true" aria-labelledby="unsent-title"><h2 id="unsent-title">放棄未提交的更改？</h2><p>這些更改尚未送出。離開後，需要重新填寫。</p><div class="actions"><button class="button" data-keep>繼續編輯</button><button class="button secondary" data-discard>放棄更改並離開</button></div></section></div>`
  );
  root.querySelector("[data-keep]").focus();
}
function finishSensitive() {
  const { id, result } = sensitive;
  confirmationValid = true;
  if (id === "create") navigate("handover", "created", true);
  else if (id === "recovery") navigate("handover", result, true);
  else navigate(id, result, true);
}
root.addEventListener("input", (event) => {
  const input = event.target;
  if (input.matches("[data-search]")) {
    const term = input.value.trim().toLowerCase();
    let count = 0;
    root.querySelectorAll("[data-searchable]").forEach((row) => {
      row.hidden = !row.dataset.searchable.toLowerCase().includes(term);
      if (!row.hidden) count++;
    });
    const counter = root.querySelector(".result-count");
    if (counter) counter.textContent = `${count} 個帳戶`;
    const none = root.querySelector("[data-search-empty]");
    if (none) none.hidden = count !== 0;
    return;
  }
  if (input.matches("input,textarea,select")) {
    if (input.name === "confirmPassword") input.setCustomValidity("");
    dirty = true;
    const values = drafts.get(current) || {};
    if (!/password/i.test(input.name))
      values[input.name] =
        input.type === "checkbox" ? input.checked : input.value;
    drafts.set(current, values);
  }
});
root.addEventListener("change", (event) => {
  if (
    event.target.name === "identityCheck" ||
    event.target.name === "recoveryAction"
  ) {
    const values = drafts.get(current) || {};
    values[event.target.name] = event.target.value;
    drafts.set(current, values);
  }
});
root.addEventListener("submit", (event) => {
  event.preventDefault();
  const form = event.target;
  const data = new FormData(form);
  if (
    data.has("newPassword") &&
    data.get("newPassword") !== data.get("confirmPassword")
  ) {
    form
      .querySelector("[name=confirmPassword]")
      .setCustomValidity("兩次輸入的新密碼不相符。");
    form.reportValidity();
    return;
  }
  if (current === "confirm") {
    confirmationValid = true;
    dirty = false;
    navigate(
      sensitive.id,
      sensitive.id === "security"
        ? "confirmed"
        : sensitive.reviewState || "review",
      true
    );
    return;
  }
  let nextState = form.dataset.state;
  if (current === "recovery")
    nextState = data.get("recoveryAction") || nextState;
  dirty = false;
  navigate(form.dataset.submit, nextState, true);
});
root.addEventListener("click", (event) => {
  const control = event.target.closest("a,button");
  if (!control) return;
  if (control.hasAttribute("data-eye")) {
    const input = control.parentElement.querySelector("input");
    input.type = input.type === "password" ? "text" : "password";
    control.setAttribute(
      "aria-label",
      input.type === "password" ? "顯示密碼" : "隱藏密碼"
    );
    return;
  }
  if (control.hasAttribute("data-keep")) {
    root.querySelector("[data-live-dialog]").remove();
    return;
  }
  if (control.hasAttribute("data-discard")) {
    drafts.delete(current);
    dirty = false;
    const next = pendingNavigation;
    pendingNavigation = null;
    navigate(...next, true);
    return;
  }
  if (control.hasAttribute("data-sensitive")) {
    event.preventDefault();
    const required = root.querySelector("input[name=deleteAcknowledged]");
    if (required && !required.checked) {
      required.reportValidity();
      return;
    }
    sensitive = {
      id: control.dataset.sensitive,
      result: control.dataset.result,
      reviewState: state,
    };
    dirty = false;
    if (!confirmationValid) navigate("confirm", "default", true);
    else finishSensitive();
    return;
  }
  if (control.hasAttribute("data-final-submit")) {
    finishSensitive();
    return;
  }
  if (control.hasAttribute("data-scroll")) {
    event.preventDefault();
    document
      .querySelector("#" + control.dataset.scroll)
      .scrollIntoView({ behavior: "smooth" });
    return;
  }
  if (control.hasAttribute("data-week")) {
    week = Math.max(0, week + Number(control.dataset.week));
    const dates = weekDates(week);
    root.querySelectorAll(".day").forEach((day, i) => {
      day.dataset.day = dates[i];
      day.querySelector("span").textContent = Number(dates[i].slice(8));
      day.classList.toggle("today", week === 0 && i === 0);
      day.classList.remove("selected");
      if (["2026-10-11", "2026-10-18"].includes(dates[i]))
        day.dataset.event = "true";
      else delete day.dataset.event;
    });
    const first = new Date(dates[0] + "T00:00:00Z"),
      last = new Date(dates.at(-1) + "T00:00:00Z");
    root.querySelector("[data-month]").textContent =
      first.getUTCMonth() === last.getUTCMonth()
        ? `${first.getUTCFullYear()} 年 ${first.getUTCMonth() + 1} 月`
        : `${first.getUTCFullYear()} 年 ${first.getUTCMonth() + 1}–${last.getUTCMonth() + 1} 月`;
    root.querySelector('[data-week="-1"]').disabled = week === 0;
    return;
  }
  if (control.hasAttribute("data-day")) {
    const raw = control.dataset.day;
    const date = raw.includes("-") ? raw : `2026-10-${raw.padStart(2, "0")}`;
    const day = Number(date.slice(8)),
      month = Number(date.slice(5, 7));
    root
      .querySelectorAll(".day")
      .forEach((button) =>
        button.classList.toggle("selected", button === control)
      );
    root.querySelector("[data-agenda]").innerHTML = [
      "2026-10-11",
      "2026-10-18",
    ].includes(date)
      ? `<article class="event"><div class="event-date"><strong>${day}</strong>週日</div><div class="event-body"><h3>主日崇拜</h3><p>10:30 · 敬拜部</p><span class="badge">報名已批准</span></div></article>`
      : `<div class="empty">${icon("CalendarDays")}<h2>這一天沒有聚會</h2><p>試試其他日期，或查看全部即將參與的聚會。</p><button class="button secondary" data-go="home">查看全部</button></div>`;
    root
      .querySelector("[data-agenda]")
      .previousElementSibling.querySelector(
        "h2"
      ).textContent = `${month} 月 ${day} 日的聚會`;
    return;
  }
  if (control.dataset.go) {
    event.preventDefault();
    if (control.hasAttribute("data-reset-application")) {
      drafts.delete("apply");
      drafts.delete("apply-result");
      originalOperation = false;
      dirty = false;
    }
    if (control.dataset.person) {
      const [name, username] = control.dataset.person.split("|");
      person = { name, username };
    }
    if (control.hasAttribute("data-retry")) originalOperation = true;
    if (control.dataset.go === "confirm" && current === "security")
      sensitive = { id: "security", result: "confirmed" };
    if (current === "handover" && control.dataset.go === "person") {
      const acknowledged = root.querySelector("[name=handover]");
      if (acknowledged && !acknowledged.checked) {
        acknowledged.reportValidity();
        return;
      }
    }
    navigate(control.dataset.go, control.dataset.state || "");
  }
});
document.addEventListener("keydown", (event) => {
  const dialog = root.querySelector("[role=dialog]");
  if (!dialog) return;
  const focusable = [
    ...dialog.querySelectorAll(
      "input:not(:disabled),button:not(:disabled),a[href],textarea,select"
    ),
  ];
  if (event.key === "Tab" && focusable.length) {
    const first = focusable[0],
      last = focusable.at(-1);
    if (event.shiftKey && document.activeElement === first) {
      event.preventDefault();
      last.focus();
    } else if (!event.shiftKey && document.activeElement === last) {
      event.preventDefault();
      first.focus();
    }
  }
  if (event.key === "Escape" && root.querySelector("[data-live-dialog]"))
    root.querySelector("[data-live-dialog]").remove();
});
window.addEventListener("beforeunload", (event) => {
  if (dirty) {
    event.preventDefault();
    event.returnValue = "";
  }
});
if (getScreen(current).group.startsWith("03") || state === "staff")
  role = "staff";
if (current === "restrictions")
  restriction = {
    banned: ["banned", "combined"].includes(state),
    deactivated: ["deactivated", "combined"].includes(state),
  };
render();
