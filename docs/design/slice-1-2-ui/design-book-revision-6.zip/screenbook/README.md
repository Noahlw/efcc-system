# EFCC UI design book

Revision 6 · 5 October 2026 · Selected calm teal direction.

Run from this directory with Node:

```sh
node serve.mjs
```

Open http://127.0.0.1:4323/. Select a screen in the left catalogue, choose its state, and switch between Mobile and Desktop. “總覽” opens four sheets of all 40 primary designs; “獨立檢視” opens the current full screen.

All data and actions are synthetic. State lives in memory and is reset on reload. The preview does not contact application APIs or a database. It is a design-review artifact, not the production UI.

Run the bounded check with `node check.mjs`. Coverage and evidence are in [coverage.md](coverage.md) and [design-qa.md](design-qa.md). Icons are unmodified Lucide library exports; their licence is in `assets/LUCIDE-LICENSE`.

This is the immutable Revision 6 design snapshot published for implementation reference, from main `100bde8`. The owner invoked spec and ticket authoring after reviewing this design book. GitHub Issues remain the canonical specification and implementation scope.
